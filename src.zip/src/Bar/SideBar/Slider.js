import React, {Component} from 'react';

class  Slider extends Component{
    render() {
        return(
        <div class="slider">
              <div class="slider-text">
                <h1>This is Slider text</h1>
                <h2>This is small slider text</h2>
              </div>
        </div>

        );
    }
}

export default Slider;
