import React, {Component} from "react";
import {BrowserRouter as Router, Link, Route} from "react-router-dom";

const Detail = (props) => {
    // let id=props.key;

    return (

            <div>this is detail
            </div>

    );
}

export default Detail;
